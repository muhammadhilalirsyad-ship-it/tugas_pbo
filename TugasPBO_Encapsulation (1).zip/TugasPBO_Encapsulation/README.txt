TUGAS PBO PERTEMUAN 8 - ENCAPSULATION

Cara menjalankan di NetBeans:
1. Ekstrak folder TugasPBO_Encapsulation.
2. Buat project Java baru bernama TugasPBO_Encapsulation (atau buka folder ini sebagai project Java dengan source folder src).
3. Pastikan semua file berada pada package tugaspbo.
4. Jalankan file Main.java.

Class:
- BangunDatar: parent class abstrak dengan method hitungLuas() dan hitungKeliling().
- Persegi, PersegiPanjang, Lingkaran, Segitiga: child class yang extends BangunDatar dan override kedua method.
- Main: membuat objek, mengisi atribut melalui setter, dan menampilkan hasil.

Catatan:
Nilai contoh dapat diubah di Main.java. Keliling segitiga dihitung dari tiga sisi, sehingga perlu mengisi sisiA, sisiB, dan sisiC melalui setter.
Struktur class ini dibuat berdasarkan instruksi tugas yang terlihat. Karena slide class diagram asli belum tersedia, nama/jenis class mungkin perlu disesuaikan jika diagram dosen berbeda.
