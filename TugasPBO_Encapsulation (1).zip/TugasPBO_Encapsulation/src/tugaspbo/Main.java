package tugaspbo;

public class Main {
    public static void main(String[] args) {
        Persegi persegi = new Persegi();
        persegi.setSisi(5);

        PersegiPanjang persegiPanjang = new PersegiPanjang();
        persegiPanjang.setPanjang(8);
        persegiPanjang.setLebar(4);

        Lingkaran lingkaran = new Lingkaran();
        lingkaran.setJariJari(7);

        Segitiga segitiga = new Segitiga();
        segitiga.setAlas(6);
        segitiga.setTinggi(4);
        segitiga.setSisiA(5);
        segitiga.setSisiB(5);
        segitiga.setSisiC(6);

        System.out.println("===== PROGRAM MENGHITUNG BANGUN DATAR =====");
        tampilkanHasil("PERSEGI", persegi);
        tampilkanHasil("PERSEGI PANJANG", persegiPanjang);
        tampilkanHasil("LINGKARAN", lingkaran);
        tampilkanHasil("SEGITIGA", segitiga);
    }

    public static void tampilkanHasil(String nama, BangunDatar bangun) {
        System.out.println("\n--- " + nama + " ---");
        System.out.printf("Luas      : %.2f%n", bangun.hitungLuas());
        System.out.printf("Keliling  : %.2f%n", bangun.hitungKeliling());
    }
}
