package tugaspbo;

public class Persegi extends BangunDatar {
    private double sisi;

    public double getSisi() { return sisi; }
    public void setSisi(double sisi) {
        if (sisi < 0) throw new IllegalArgumentException("Sisi tidak boleh negatif.");
        this.sisi = sisi;
    }

    @Override
    public double hitungLuas() { return sisi * sisi; }

    @Override
    public double hitungKeliling() { return 4 * sisi; }
}
