package tugaspbo;

public class Lingkaran extends BangunDatar {
    private double jariJari;

    public double getJariJari() { return jariJari; }
    public void setJariJari(double jariJari) {
        if (jariJari < 0) throw new IllegalArgumentException("Jari-jari tidak boleh negatif.");
        this.jariJari = jariJari;
    }

    @Override
    public double hitungLuas() { return Math.PI * jariJari * jariJari; }

    @Override
    public double hitungKeliling() { return 2 * Math.PI * jariJari; }
}
