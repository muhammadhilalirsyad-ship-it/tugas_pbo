package tugaspbo;

public class Segitiga extends BangunDatar {
    private double alas;
    private double tinggi;
    private double sisiA;
    private double sisiB;
    private double sisiC;

    public double getAlas() { return alas; }
    public void setAlas(double alas) {
        if (alas < 0) throw new IllegalArgumentException("Alas tidak boleh negatif.");
        this.alas = alas;
    }
    public double getTinggi() { return tinggi; }
    public void setTinggi(double tinggi) {
        if (tinggi < 0) throw new IllegalArgumentException("Tinggi tidak boleh negatif.");
        this.tinggi = tinggi;
    }
    public double getSisiA() { return sisiA; }
    public void setSisiA(double sisiA) {
        if (sisiA < 0) throw new IllegalArgumentException("Sisi tidak boleh negatif.");
        this.sisiA = sisiA;
    }
    public double getSisiB() { return sisiB; }
    public void setSisiB(double sisiB) {
        if (sisiB < 0) throw new IllegalArgumentException("Sisi tidak boleh negatif.");
        this.sisiB = sisiB;
    }
    public double getSisiC() { return sisiC; }
    public void setSisiC(double sisiC) {
        if (sisiC < 0) throw new IllegalArgumentException("Sisi tidak boleh negatif.");
        this.sisiC = sisiC;
    }

    @Override
    public double hitungLuas() { return 0.5 * alas * tinggi; }

    @Override
    public double hitungKeliling() { return sisiA + sisiB + sisiC; }
}
