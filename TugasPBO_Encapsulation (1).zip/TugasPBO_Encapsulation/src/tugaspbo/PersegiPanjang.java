package tugaspbo;

public class PersegiPanjang extends BangunDatar {
    private double panjang;
    private double lebar;

    public double getPanjang() { return panjang; }
    public void setPanjang(double panjang) {
        if (panjang < 0) throw new IllegalArgumentException("Panjang tidak boleh negatif.");
        this.panjang = panjang;
    }
    public double getLebar() { return lebar; }
    public void setLebar(double lebar) {
        if (lebar < 0) throw new IllegalArgumentException("Lebar tidak boleh negatif.");
        this.lebar = lebar;
    }

    @Override
    public double hitungLuas() { return panjang * lebar; }

    @Override
    public double hitungKeliling() { return 2 * (panjang + lebar); }
}
